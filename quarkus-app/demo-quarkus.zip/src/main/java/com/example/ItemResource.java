package com.example;

import com.example.model.Item;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path("/items")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ItemResource {

    @GET
    public List<Item> list() {
        return Item.listAll();
    }

    @POST
    public Item create(Item item) {
        item.persist();
        return item;
    }

    @GET
    @Path("{id}")
    public Item get(@PathParam("id") Long id) {
        return Item.findById(id);
    }

    @DELETE
    @Path("{id}")
    public void delete(@PathParam("id") Long id) {
        boolean deleted = Item.deleteById(id);
        if (!deleted) {
            throw new NotFoundException("Item not found");
        }
    }
}
