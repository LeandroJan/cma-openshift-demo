#!/bin/sh
echo "To get the Maven wrapper, run: mvn -N io.takari:maven:wrapper"
echo "Alternatively, install Maven and use 'mvn' directly, e.g.: mvn compile quarkus:dev"
